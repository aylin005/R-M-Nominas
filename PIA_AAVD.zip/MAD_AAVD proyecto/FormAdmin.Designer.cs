﻿namespace MAD_AAVD_proyecto
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAdmin));
            this.SM_Panel = new System.Windows.Forms.Panel();
            this.SM_Headcounter = new System.Windows.Forms.Button();
            this.SM_Panel_SubMenuNomina = new System.Windows.Forms.Panel();
            this.SM_Nomina_EmployReport = new System.Windows.Forms.Button();
            this.SM_Nomina_Reporte = new System.Windows.Forms.Button();
            this.SM_Nomina_Generar = new System.Windows.Forms.Button();
            this.SM_Nomina = new System.Windows.Forms.Button();
            this.SM_Panel_SubMenuConceptos = new System.Windows.Forms.Panel();
            this.SM_Conceptos_Aplicar = new System.Windows.Forms.Button();
            this.SM_Conceptos_Catalogo = new System.Windows.Forms.Button();
            this.SM_Conceptos = new System.Windows.Forms.Button();
            this.SM_Departamentos = new System.Windows.Forms.Button();
            this.SM_Puestos = new System.Windows.Forms.Button();
            this.SM_Empleados = new System.Windows.Forms.Button();
            this.SM_Panel_Logo = new System.Windows.Forms.Panel();
            this.SM_Logout = new System.Windows.Forms.Button();
            this.TopBar = new System.Windows.Forms.Panel();
            this.ADMIN_Close = new System.Windows.Forms.Button();
            this.ADMIN_PanelChildForm = new System.Windows.Forms.Panel();
            this.SM_Panel.SuspendLayout();
            this.SM_Panel_SubMenuNomina.SuspendLayout();
            this.SM_Panel_SubMenuConceptos.SuspendLayout();
            this.TopBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // SM_Panel
            // 
            this.SM_Panel.AutoScroll = true;
            this.SM_Panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(14)))), ((int)(((byte)(19)))));
            this.SM_Panel.Controls.Add(this.SM_Headcounter);
            this.SM_Panel.Controls.Add(this.SM_Panel_SubMenuNomina);
            this.SM_Panel.Controls.Add(this.SM_Nomina);
            this.SM_Panel.Controls.Add(this.SM_Panel_SubMenuConceptos);
            this.SM_Panel.Controls.Add(this.SM_Conceptos);
            this.SM_Panel.Controls.Add(this.SM_Departamentos);
            this.SM_Panel.Controls.Add(this.SM_Puestos);
            this.SM_Panel.Controls.Add(this.SM_Empleados);
            this.SM_Panel.Controls.Add(this.SM_Panel_Logo);
            this.SM_Panel.Controls.Add(this.SM_Logout);
            this.SM_Panel.Dock = System.Windows.Forms.DockStyle.Left;
            this.SM_Panel.Location = new System.Drawing.Point(0, 0);
            this.SM_Panel.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Panel.Name = "SM_Panel";
            this.SM_Panel.Size = new System.Drawing.Size(197, 743);
            this.SM_Panel.TabIndex = 0;
            this.SM_Panel.Paint += new System.Windows.Forms.PaintEventHandler(this.SM_Panel_Paint);
            // 
            // SM_Headcounter
            // 
            this.SM_Headcounter.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Headcounter.FlatAppearance.BorderSize = 0;
            this.SM_Headcounter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Headcounter.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Headcounter.ForeColor = System.Drawing.Color.AliceBlue;
            this.SM_Headcounter.Image = ((System.Drawing.Image)(resources.GetObject("SM_Headcounter.Image")));
            this.SM_Headcounter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Headcounter.Location = new System.Drawing.Point(0, 530);
            this.SM_Headcounter.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Headcounter.Name = "SM_Headcounter";
            this.SM_Headcounter.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.SM_Headcounter.Size = new System.Drawing.Size(197, 47);
            this.SM_Headcounter.TabIndex = 15;
            this.SM_Headcounter.Text = "  Headcounter";
            this.SM_Headcounter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Headcounter.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SM_Headcounter.UseVisualStyleBackColor = true;
            this.SM_Headcounter.Click += new System.EventHandler(this.SM_Headcounter_Click);
            // 
            // SM_Panel_SubMenuNomina
            // 
            this.SM_Panel_SubMenuNomina.BackColor = System.Drawing.Color.Gray;
            this.SM_Panel_SubMenuNomina.Controls.Add(this.SM_Nomina_EmployReport);
            this.SM_Panel_SubMenuNomina.Controls.Add(this.SM_Nomina_Reporte);
            this.SM_Panel_SubMenuNomina.Controls.Add(this.SM_Nomina_Generar);
            this.SM_Panel_SubMenuNomina.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Panel_SubMenuNomina.Location = new System.Drawing.Point(0, 412);
            this.SM_Panel_SubMenuNomina.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Panel_SubMenuNomina.Name = "SM_Panel_SubMenuNomina";
            this.SM_Panel_SubMenuNomina.Size = new System.Drawing.Size(197, 118);
            this.SM_Panel_SubMenuNomina.TabIndex = 12;
            // 
            // SM_Nomina_EmployReport
            // 
            this.SM_Nomina_EmployReport.BackColor = System.Drawing.Color.Black;
            this.SM_Nomina_EmployReport.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Nomina_EmployReport.FlatAppearance.BorderSize = 0;
            this.SM_Nomina_EmployReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Nomina_EmployReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Nomina_EmployReport.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.SM_Nomina_EmployReport.Location = new System.Drawing.Point(0, 74);
            this.SM_Nomina_EmployReport.Name = "SM_Nomina_EmployReport";
            this.SM_Nomina_EmployReport.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.SM_Nomina_EmployReport.Size = new System.Drawing.Size(197, 44);
            this.SM_Nomina_EmployReport.TabIndex = 19;
            this.SM_Nomina_EmployReport.Text = "Reporte General de Nómina";
            this.SM_Nomina_EmployReport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Nomina_EmployReport.UseVisualStyleBackColor = false;
            this.SM_Nomina_EmployReport.Click += new System.EventHandler(this.SM_Nomina_EmployReport_Click);
            // 
            // SM_Nomina_Reporte
            // 
            this.SM_Nomina_Reporte.BackColor = System.Drawing.Color.Black;
            this.SM_Nomina_Reporte.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Nomina_Reporte.FlatAppearance.BorderSize = 0;
            this.SM_Nomina_Reporte.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Nomina_Reporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Nomina_Reporte.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.SM_Nomina_Reporte.Location = new System.Drawing.Point(0, 37);
            this.SM_Nomina_Reporte.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Nomina_Reporte.Name = "SM_Nomina_Reporte";
            this.SM_Nomina_Reporte.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.SM_Nomina_Reporte.Size = new System.Drawing.Size(197, 37);
            this.SM_Nomina_Reporte.TabIndex = 18;
            this.SM_Nomina_Reporte.Text = "Reporte de nómina";
            this.SM_Nomina_Reporte.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Nomina_Reporte.UseVisualStyleBackColor = false;
            this.SM_Nomina_Reporte.Click += new System.EventHandler(this.SM_Nomina_Reporte_Click);
            // 
            // SM_Nomina_Generar
            // 
            this.SM_Nomina_Generar.BackColor = System.Drawing.Color.Black;
            this.SM_Nomina_Generar.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Nomina_Generar.FlatAppearance.BorderSize = 0;
            this.SM_Nomina_Generar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Nomina_Generar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Nomina_Generar.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.SM_Nomina_Generar.Location = new System.Drawing.Point(0, 0);
            this.SM_Nomina_Generar.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Nomina_Generar.Name = "SM_Nomina_Generar";
            this.SM_Nomina_Generar.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.SM_Nomina_Generar.Size = new System.Drawing.Size(197, 37);
            this.SM_Nomina_Generar.TabIndex = 17;
            this.SM_Nomina_Generar.Text = "Generar nómina";
            this.SM_Nomina_Generar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Nomina_Generar.UseVisualStyleBackColor = false;
            this.SM_Nomina_Generar.Click += new System.EventHandler(this.SM_Nomina_Generar_Click);
            // 
            // SM_Nomina
            // 
            this.SM_Nomina.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Nomina.FlatAppearance.BorderSize = 0;
            this.SM_Nomina.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Nomina.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Nomina.ForeColor = System.Drawing.Color.AliceBlue;
            this.SM_Nomina.Image = ((System.Drawing.Image)(resources.GetObject("SM_Nomina.Image")));
            this.SM_Nomina.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Nomina.Location = new System.Drawing.Point(0, 365);
            this.SM_Nomina.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Nomina.Name = "SM_Nomina";
            this.SM_Nomina.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.SM_Nomina.Size = new System.Drawing.Size(197, 47);
            this.SM_Nomina.TabIndex = 11;
            this.SM_Nomina.Text = "  Nómina";
            this.SM_Nomina.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Nomina.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SM_Nomina.UseVisualStyleBackColor = true;
            this.SM_Nomina.Click += new System.EventHandler(this.SM_Nomina_Click);
            // 
            // SM_Panel_SubMenuConceptos
            // 
            this.SM_Panel_SubMenuConceptos.BackColor = System.Drawing.Color.Black;
            this.SM_Panel_SubMenuConceptos.Controls.Add(this.SM_Conceptos_Aplicar);
            this.SM_Panel_SubMenuConceptos.Controls.Add(this.SM_Conceptos_Catalogo);
            this.SM_Panel_SubMenuConceptos.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Panel_SubMenuConceptos.Location = new System.Drawing.Point(0, 288);
            this.SM_Panel_SubMenuConceptos.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Panel_SubMenuConceptos.Name = "SM_Panel_SubMenuConceptos";
            this.SM_Panel_SubMenuConceptos.Size = new System.Drawing.Size(197, 77);
            this.SM_Panel_SubMenuConceptos.TabIndex = 10;
            // 
            // SM_Conceptos_Aplicar
            // 
            this.SM_Conceptos_Aplicar.BackColor = System.Drawing.Color.Black;
            this.SM_Conceptos_Aplicar.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Conceptos_Aplicar.FlatAppearance.BorderSize = 0;
            this.SM_Conceptos_Aplicar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Conceptos_Aplicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Conceptos_Aplicar.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.SM_Conceptos_Aplicar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SM_Conceptos_Aplicar.Location = new System.Drawing.Point(0, 38);
            this.SM_Conceptos_Aplicar.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Conceptos_Aplicar.Name = "SM_Conceptos_Aplicar";
            this.SM_Conceptos_Aplicar.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.SM_Conceptos_Aplicar.Size = new System.Drawing.Size(197, 39);
            this.SM_Conceptos_Aplicar.TabIndex = 1;
            this.SM_Conceptos_Aplicar.Text = "Aplicar conceptos";
            this.SM_Conceptos_Aplicar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Conceptos_Aplicar.UseVisualStyleBackColor = false;
            this.SM_Conceptos_Aplicar.Click += new System.EventHandler(this.SM_Conceptos_Aplicar_Click);
            // 
            // SM_Conceptos_Catalogo
            // 
            this.SM_Conceptos_Catalogo.BackColor = System.Drawing.Color.Black;
            this.SM_Conceptos_Catalogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Conceptos_Catalogo.FlatAppearance.BorderSize = 0;
            this.SM_Conceptos_Catalogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Conceptos_Catalogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Conceptos_Catalogo.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.SM_Conceptos_Catalogo.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SM_Conceptos_Catalogo.Location = new System.Drawing.Point(0, 0);
            this.SM_Conceptos_Catalogo.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Conceptos_Catalogo.Name = "SM_Conceptos_Catalogo";
            this.SM_Conceptos_Catalogo.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.SM_Conceptos_Catalogo.Size = new System.Drawing.Size(197, 38);
            this.SM_Conceptos_Catalogo.TabIndex = 0;
            this.SM_Conceptos_Catalogo.Text = "Cátalogo de conceptos";
            this.SM_Conceptos_Catalogo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Conceptos_Catalogo.UseVisualStyleBackColor = false;
            this.SM_Conceptos_Catalogo.Click += new System.EventHandler(this.SM_Conceptos_Catalogo_Click);
            // 
            // SM_Conceptos
            // 
            this.SM_Conceptos.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Conceptos.FlatAppearance.BorderSize = 0;
            this.SM_Conceptos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Conceptos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Conceptos.ForeColor = System.Drawing.Color.AliceBlue;
            this.SM_Conceptos.Image = ((System.Drawing.Image)(resources.GetObject("SM_Conceptos.Image")));
            this.SM_Conceptos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Conceptos.Location = new System.Drawing.Point(0, 241);
            this.SM_Conceptos.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Conceptos.Name = "SM_Conceptos";
            this.SM_Conceptos.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.SM_Conceptos.Size = new System.Drawing.Size(197, 47);
            this.SM_Conceptos.TabIndex = 10;
            this.SM_Conceptos.Text = "  Conceptos";
            this.SM_Conceptos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Conceptos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SM_Conceptos.UseVisualStyleBackColor = true;
            this.SM_Conceptos.Click += new System.EventHandler(this.SM_Conceptos_Click);
            // 
            // SM_Departamentos
            // 
            this.SM_Departamentos.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Departamentos.FlatAppearance.BorderSize = 0;
            this.SM_Departamentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Departamentos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Departamentos.ForeColor = System.Drawing.Color.AliceBlue;
            this.SM_Departamentos.Image = ((System.Drawing.Image)(resources.GetObject("SM_Departamentos.Image")));
            this.SM_Departamentos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Departamentos.Location = new System.Drawing.Point(0, 194);
            this.SM_Departamentos.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Departamentos.Name = "SM_Departamentos";
            this.SM_Departamentos.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.SM_Departamentos.Size = new System.Drawing.Size(197, 47);
            this.SM_Departamentos.TabIndex = 9;
            this.SM_Departamentos.Text = "  Departamentos";
            this.SM_Departamentos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Departamentos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SM_Departamentos.UseVisualStyleBackColor = true;
            this.SM_Departamentos.Click += new System.EventHandler(this.SM_Departamentos_Click);
            // 
            // SM_Puestos
            // 
            this.SM_Puestos.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Puestos.FlatAppearance.BorderSize = 0;
            this.SM_Puestos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Puestos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Puestos.ForeColor = System.Drawing.Color.AliceBlue;
            this.SM_Puestos.Image = ((System.Drawing.Image)(resources.GetObject("SM_Puestos.Image")));
            this.SM_Puestos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Puestos.Location = new System.Drawing.Point(0, 147);
            this.SM_Puestos.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Puestos.Name = "SM_Puestos";
            this.SM_Puestos.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.SM_Puestos.Size = new System.Drawing.Size(197, 47);
            this.SM_Puestos.TabIndex = 8;
            this.SM_Puestos.Text = "  Puestos";
            this.SM_Puestos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Puestos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SM_Puestos.UseVisualStyleBackColor = true;
            this.SM_Puestos.Click += new System.EventHandler(this.SM_Puestos_Click);
            // 
            // SM_Empleados
            // 
            this.SM_Empleados.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Empleados.FlatAppearance.BorderSize = 0;
            this.SM_Empleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Empleados.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Empleados.ForeColor = System.Drawing.Color.AliceBlue;
            this.SM_Empleados.Image = ((System.Drawing.Image)(resources.GetObject("SM_Empleados.Image")));
            this.SM_Empleados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Empleados.Location = new System.Drawing.Point(0, 100);
            this.SM_Empleados.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Empleados.Name = "SM_Empleados";
            this.SM_Empleados.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.SM_Empleados.Size = new System.Drawing.Size(197, 47);
            this.SM_Empleados.TabIndex = 6;
            this.SM_Empleados.Text = "  Empleados";
            this.SM_Empleados.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SM_Empleados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SM_Empleados.UseVisualStyleBackColor = true;
            this.SM_Empleados.Click += new System.EventHandler(this.SM_Empleados_Click);
            // 
            // SM_Panel_Logo
            // 
            this.SM_Panel_Logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.SM_Panel_Logo.Location = new System.Drawing.Point(0, 0);
            this.SM_Panel_Logo.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Panel_Logo.Name = "SM_Panel_Logo";
            this.SM_Panel_Logo.Size = new System.Drawing.Size(197, 100);
            this.SM_Panel_Logo.TabIndex = 5;
            // 
            // SM_Logout
            // 
            this.SM_Logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(35)))));
            this.SM_Logout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.SM_Logout.FlatAppearance.BorderSize = 0;
            this.SM_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SM_Logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SM_Logout.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.SM_Logout.Location = new System.Drawing.Point(0, 703);
            this.SM_Logout.Margin = new System.Windows.Forms.Padding(2);
            this.SM_Logout.Name = "SM_Logout";
            this.SM_Logout.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.SM_Logout.Size = new System.Drawing.Size(197, 40);
            this.SM_Logout.TabIndex = 4;
            this.SM_Logout.Text = "Cerrar sesión";
            this.SM_Logout.UseVisualStyleBackColor = false;
            this.SM_Logout.Click += new System.EventHandler(this.SM_Logout_Click);
            // 
            // TopBar
            // 
            this.TopBar.BackColor = System.Drawing.Color.Black;
            this.TopBar.Controls.Add(this.ADMIN_Close);
            this.TopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.TopBar.Location = new System.Drawing.Point(197, 0);
            this.TopBar.Name = "TopBar";
            this.TopBar.Size = new System.Drawing.Size(983, 34);
            this.TopBar.TabIndex = 0;
            // 
            // ADMIN_Close
            // 
            this.ADMIN_Close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ADMIN_Close.BackgroundImage")));
            this.ADMIN_Close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ADMIN_Close.Dock = System.Windows.Forms.DockStyle.Right;
            this.ADMIN_Close.FlatAppearance.BorderSize = 0;
            this.ADMIN_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ADMIN_Close.Location = new System.Drawing.Point(947, 0);
            this.ADMIN_Close.Name = "ADMIN_Close";
            this.ADMIN_Close.Size = new System.Drawing.Size(36, 34);
            this.ADMIN_Close.TabIndex = 0;
            this.ADMIN_Close.UseVisualStyleBackColor = true;
            this.ADMIN_Close.Click += new System.EventHandler(this.ADMIN_Close_Click);
            // 
            // ADMIN_PanelChildForm
            // 
            this.ADMIN_PanelChildForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ADMIN_PanelChildForm.Location = new System.Drawing.Point(197, 34);
            this.ADMIN_PanelChildForm.Name = "ADMIN_PanelChildForm";
            this.ADMIN_PanelChildForm.Size = new System.Drawing.Size(983, 709);
            this.ADMIN_PanelChildForm.TabIndex = 1;
            this.ADMIN_PanelChildForm.Paint += new System.Windows.Forms.PaintEventHandler(this.ADMIN_PanelChildForm_Paint);
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1180, 743);
            this.Controls.Add(this.ADMIN_PanelChildForm);
            this.Controls.Add(this.TopBar);
            this.Controls.Add(this.SM_Panel);
            this.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.SM_Panel.ResumeLayout(false);
            this.SM_Panel_SubMenuNomina.ResumeLayout(false);
            this.SM_Panel_SubMenuConceptos.ResumeLayout(false);
            this.TopBar.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel SM_Panel;
        private System.Windows.Forms.Button SM_Logout;
        private System.Windows.Forms.Panel SM_Panel_Logo;
        private System.Windows.Forms.Button SM_Empleados;
        private System.Windows.Forms.Button SM_Departamentos;
        private System.Windows.Forms.Button SM_Puestos;
        private System.Windows.Forms.Panel SM_Panel_SubMenuConceptos;
        private System.Windows.Forms.Button SM_Conceptos_Catalogo;
        private System.Windows.Forms.Button SM_Conceptos;
        private System.Windows.Forms.Button SM_Nomina;
        private System.Windows.Forms.Button SM_Conceptos_Aplicar;
        private System.Windows.Forms.Panel SM_Panel_SubMenuNomina;
        private System.Windows.Forms.Panel TopBar;
        private System.Windows.Forms.Button ADMIN_Close;
        private System.Windows.Forms.Panel ADMIN_PanelChildForm;
        private System.Windows.Forms.Button SM_Headcounter;
        private System.Windows.Forms.Button SM_Nomina_EmployReport;
        private System.Windows.Forms.Button SM_Nomina_Reporte;
        private System.Windows.Forms.Button SM_Nomina_Generar;
    }
}